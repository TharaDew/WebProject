namespace VelocityAPI.Application.Authentication.Common;

public enum TokenType
{
    AccessToken,
    RefreshToken,
    SessionToken,
    ReauthToken
}
